# the-interpreter-101
A very simple interpreter writen in C# with ANTLR4



## Project Structure

```
Project Grammar (CFG)
       \/
Lang.g4  ---> [ANTLR] ---generates---> LangLexer.cs, LangParser.cs

```

## How to run

